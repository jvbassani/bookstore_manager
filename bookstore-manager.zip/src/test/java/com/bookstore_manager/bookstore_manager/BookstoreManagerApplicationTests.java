package com.bookstore_manager.bookstore_manager;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookstoreManagerApplicationTests {

	@Test
	void contextLoads() {
	}

}
