package com.bookstore_manager.bookstore_manager;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookstoreManagerApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookstoreManagerApplication.class, args);
	}

}
